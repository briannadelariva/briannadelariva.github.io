package appointment;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//Brianna De La Riva
//Professor Krupa
//CS-499 Computer Science Capstone - Artifact One, Software Design and Engineering
//12 September 2024, date on updated final touches (19 Oct 2024)

public class Appointment {

    private String appointmentID;
    private String appointmentDescription;
    private LocalDate appointmentDate; // Changed from util Date to LocalDate per instructor improvement feedback

    // Added attributes for recurring appointments enhancement
    private List<LocalDate> recurringAppointments = new ArrayList<>();

    public Appointment() {
        recurringAppointments = new ArrayList<>();
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(String newAppointmentID) {
        // Appointment ID requirements 
        if (newAppointmentID == null || newAppointmentID.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must not be null and cannot be longer than 10 characters.");
        }

        if (this.appointmentID != null) {
            throw new IllegalArgumentException("Appointment ID cannot be updated.");
        }

        this.appointmentID = newAppointmentID;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    public void setAppointmentDescription(String newAppointmentDescription) {
        // Appointment description requirements
        if (newAppointmentDescription == null || newAppointmentDescription.length() > 50) {
            throw new IllegalArgumentException("Appointment description must not be null and cannot be longer than 50 characters.");
        }
        this.appointmentDescription = newAppointmentDescription;
    }

    public LocalDate getAppointmentDate() { // Changed return type to LocalDate
        return appointmentDate;
    }

    public void setAppointmentDate(LocalDate newAppointmentDate) { // Changed parameter type to LocalDate
        // Appointment date requirements
        if (newAppointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        // Appointment date must not be in the past, only in the future
        if (newAppointmentDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Appointment date must not be in the past.");
        }
        this.appointmentDate = newAppointmentDate;
    }

    // Method to handle recurring appointments and add it as a functionality enhancement 
    public void generateRecurringAppointments(LocalDate startDate, int recurrenceCount, String recurrenceType) { // Changed parameter type to updated  LocalDate
        LocalDate currentDate = startDate; // Use LocalDate directly

        // Loop to generate the specified number of recurring appointments
        for (int i = 1; i <= recurrenceCount; i++) {
            switch (recurrenceType.toLowerCase()) {
                case "daily":
                    currentDate = currentDate.plusDays(1); // Use LocalDate's method to add days
                    break;
                case "weekly":
                    currentDate = currentDate.plusWeeks(1); // Use LocalDate's method to add weeks
                    break;
                case "monthly":
                    currentDate = currentDate.plusMonths(1); // Use LocalDate's method to add months
                    break;
                default:
                    throw new IllegalArgumentException("Invalid recurrence type. Use 'daily', 'weekly', or 'monthly'.");
            }

            // Ensures that the next appointment is in the future too and not the past
            if (currentDate.isBefore(LocalDate.now())) {
                throw new IllegalArgumentException("Next recurring appointment cannot be in the past.");
            }

            recurringAppointments.add(currentDate); // Add LocalDate to the list
        }
    }

    // Getter for recurringAppointments
    public List<LocalDate> getRecurringAppointments() { // Changed return type to List<LocalDate>
        return recurringAppointments; // Return the list of recurring appointments
    }

    // Method to display all recurring appointments after the user has made them
    public void displayRecurringAppointments() {
        for (LocalDate appointment : recurringAppointments) { // Changed type to LocalDate
            System.out.println("Recurring appointment scheduled for: " + appointment);
        }
    }
}
