package task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

	//hash map for tasks contents
	Map<String, Task> tasks = new HashMap<String, Task>();	

	public Task get(Task task) {
		String getId = task.getTaskID();
		return tasks.get(getId);
	}
	//add tasks
	public void add(Task task) {
		tasks.put(task.getTaskID(), task);
	}
	//delete tasks
	public void delete(Task task) {
		tasks.remove(task.getTaskID());
	}
	//update tasks
	public void update(Task task) {
		tasks.put(task.getTaskID(), task);
	}
	
	
}
