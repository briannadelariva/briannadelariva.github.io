package task;

public class Task {
	
	//Brianna De La Riva
	//Professor Norman
	//Software Testing, Automation, QA CS320
	// 19 November 2023
	// This is the completed module 4 milestone where Task, TaskService, TaskTest and 
	// TaskServiceTest were added. This will serve as application unit tests for a
	//customer's mobile application and assist with adding, updating, and deleting
	//tasks from a task list and updating name or description
	
	private String taskID;
	private String name;
	private String description;

	public String getTaskID() {
		return taskID;
	}
	
	//The task object shall have a required unique task ID String that cannot be longer than 10 characters. 
	//The task ID shall not be null and shall not be update-able.

	public void setTaskID(String newTaskID) {
		//taskID requirements
	    if (newTaskID == null || newTaskID.length() > 10) {
	    	throw new IllegalArgumentException("TaskID must not be null and cannot be longer than 10 characters.");
	    }
	    
	    if (this.taskID != null) {

	    	throw new IllegalArgumentException("TaskID cannot be updated");
	    	
	    }
	    
		this.taskID = newTaskID;
	}
	
	public void setName(String newName) {
		if (newName == null || newName.length() > 20) {
	    	throw new IllegalArgumentException("Name must not be null and cannot be longer than 20 characters.");
	    }
		
		
		this.name = newName;
	}
	
	public void setDescription(String newDescription) {
		if (newDescription == null || newDescription.length() > 50) {
	    	throw new IllegalArgumentException("Description must not be null and cannot be longer than 50 characters.");
		}
		this.description = newDescription;

	}
	
	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}


	
	
}
