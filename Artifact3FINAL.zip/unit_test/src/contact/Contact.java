package contact;


/*
 * Brianna De La Riva
 * Professor Norman
 * Software testing, automation, QA CS320
 * 08 November 2023
 * 
 * Module 3 Milestone. This will serve as application unit tests for a customer's mobile application 
 * and assist with adding, updating, and delete contacts from a contact list. 
 */


public class Contact {
	private String firstName;
	private String lastName;
	private String Number;
	private String Address;
	private String contactID;


	public String getContactID() {
		return contactID;
	}

	public void setContactID(String contactID) {
		//contactID requirements
	    if (contactID == null || contactID.length() > 10) {
	    	throw new IllegalArgumentException("ContactID must not be null and cannot be longer than 10 characters.");
	    }
		this.contactID = contactID;
	}

	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		//first name requirements
	    if (firstName == null || firstName.length() > 10) {
	    	throw new IllegalArgumentException("First name must not be null and cannot be longer than 10 characters.");
	    }
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		//last name requirements 
	    if (lastName == null || lastName.length() > 10) {
	    	throw new IllegalArgumentException("Last name must not be null and cannot be longer than 10 characters.");
	    }
		this.lastName = lastName;
	}
	public String getNumber() {
		return Number;
	}
	
	public void setNumber(String number) {
		//phone number requirements
	    if (number == null || number.length() != 10) {
	    	throw new IllegalArgumentException("Number must not be null and must be exactly 10 characters.");
	    }
		Number = number;
	}
	
	
	public String getAddress() {
		return Address;
	}
	
	public void setAddress(String address) {
		//address requirements
	    if (address == null || address.length() > 30) {
	    	throw new IllegalArgumentException("Address must not be null and cannot be longer than 10 characters.");
	    }
		Address = address;
	}



}
