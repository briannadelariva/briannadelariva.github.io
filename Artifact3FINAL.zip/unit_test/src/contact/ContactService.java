package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	//hash map for contacts contents
	Map<String, Contact> contacts = new HashMap<String, Contact>();	

	public Contact get(Contact contact) {
		String getId = contact.getContactID();
		return contacts.get(getId);
	}
	//add contacts
	public void add(Contact contact) {
		contacts.put(contact.getContactID(), contact);
	}
	//delete contacts
	public void delete(Contact contact) {
		contacts.remove(contact.getContactID());
	}
	//update contacts
	public void update(Contact contact) {
		contacts.put(contact.getContactID(), contact);
	}
	
}
