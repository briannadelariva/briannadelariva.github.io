package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
	
	ContactService contactService = new ContactService();
	static Contact contact1;
	static Contact contact2;
	
	static {
		contact1 = new Contact();
		contact1.setContactID("1");
		contact1.setFirstName("1-first");
		contact2 = new Contact();
		contact2.setContactID("2");
		contact2.setFirstName("2-first");		
	}
	
	//tests that a contact may be updated
	@Test
	void testUpdate() {
        Contact contact1before = new Contact();
        contact1before.setContactID("1");
        contact1before.setFirstName("b4Up");        

        Contact contact1after = new Contact();
        contact1after.setContactID("1");
        contact1after.setFirstName("afterUp");        
        
        contactService.add(contact1before);

        contactService.update(contact1after);
        
        Contact updatedContact = contactService.get(contact1after);
        
        assertEquals(updatedContact.getFirstName(), contact1after.getFirstName(), "Didn't update the firstname");
		
	}
	
	@Test
	void testAddNull() {
        assertThrows(NullPointerException.class, () -> {
    		contactService.add(null);
          });
	}

	@Test
	void testAddValid() {
		Contact myContact = new Contact();
		myContact.setContactID("someId");
		contactService.add(myContact);
		
		// add worked when service will return contact that was added 
		Contact afterAddContact = contactService.get(myContact);
		
		// test it worked
		assertTrue(afterAddContact.getContactID().equals(myContact.getContactID()), "it is not true");
		
	}
	
	@Test
	void testDeleteNull() {
        assertThrows(NullPointerException.class, () -> {
    		contactService.delete(null);
          });
	}
	
	//tests that valid input was deleted
	@Test
	void testDeleteValid() {
		Contact testDeleteValid = contact1;
		contactService.add(testDeleteValid);
		Contact deleted = contactService.get(testDeleteValid);
		
		// testing that addition worked. 
		assertEquals(deleted.getContactID(), testDeleteValid.getContactID(),"failed to get contact that was added");
		
		contactService.delete(testDeleteValid);
		Contact gone = contactService.get(testDeleteValid);
		assertNull(gone, "Deleted is not null");
	}
	
	//if blank contact is given and attempted to be retrieved, it will have null
	@Test
	void testGetUnknown() {
		Contact testGetUnknown = new Contact();
        Contact testUnknown = contactService.get(testGetUnknown);
        assertTrue(testUnknown == null, "Test did not return null");
        
		
	}
	
	
}
