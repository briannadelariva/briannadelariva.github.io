package appointment;


import java.util.Date; 

public class Appointment {
		
	
	private String appointmentID;
	private String appointmentDescription;
	private Date appointmentDate;


	public String getAppointmentID() {
		return appointmentID;
	}
	
	public void setAppointmentID(String newAppointmentID) {
		//appointmentID requirements
	    if (newAppointmentID == null || newAppointmentID.length() > 10) {
	    	throw new IllegalArgumentException("AppointmentID must not be null and cannot be longer than 10 characters.");
	    }
	    
	    if (this.appointmentID != null) {

	    	throw new IllegalArgumentException("AppointmentID cannot be updated");
	    	
	    }
	    
		this.appointmentID = newAppointmentID;
	}
	
	public void setAppointmentDescription(String newAppointmentDescription) {
		// appointmentDescription requirements
	    if (newAppointmentDescription == null || newAppointmentDescription.length() > 50) {
	    	throw new IllegalArgumentException("Appointment Description must not be null and cannot be longer than 50 characters.");
	    }
	    this.appointmentDescription = newAppointmentDescription;
	}
	
	public void setAppointmentDate(Date newAppointmentDate) {
		//appointmentDate requirements
		
		if (newAppointmentDate == null) {
	    	throw new IllegalArgumentException("Appointment Date must not be null.");
		}
		//appointmentDate requirements not in past
		if (newAppointmentDate.before(new Date())){
	    	throw new IllegalArgumentException("Appointment Date must not be in the past.");
		}
        this.appointmentDate = newAppointmentDate;
	}
	

	
}




