package appointment;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Date;


import org.junit.jupiter.api.Test;


public class AppointmentTest {
	Appointment appointment = new Appointment();
	Date appointmentDate = new Date();
	
	
	@Test 
	//tests for when appointmentID is null
	public void appointmentIDCheckForNull() {
        assertThrows(IllegalArgumentException.class, () -> {
    		appointment.setAppointmentID(null);
          });
	}
		
		//  tests that updates are not able to be done to initial appointmentID 
	@Test
	public void appointmentTestNonUpdateableNewValue() {
		appointment.setAppointmentID("867"); 
        assertThrows(IllegalArgumentException.class, () -> {
    		appointment.setAppointmentID("5309");
          });
	}

	// tests if update is the same as initial
	@Test
	public void appointmentTestNonUpdateableSameValue() {
		appointment.setAppointmentID("867"); 
        assertThrows(IllegalArgumentException.class, () -> {
        	appointment.setAppointmentID("867");
          });
	}
	
	//tests if appointmentID is longer than ten
	@Test
	public void appointmentTestNotLongerThanTen() {
        assertThrows(IllegalArgumentException.class, () -> {
    		appointment.setAppointmentID("I am longer than ten");
        });    
	}
	
	//tests if appointmentDate is null
	@Test
	public void appointmentDateCheckForNull() {
        assertThrows(IllegalArgumentException.class, () -> {
    		appointment.setAppointmentDate(null);
          });
	}

	//tests if appointmentDate is in the past
	@Test
	public void appointmentDateIsPast() {
        assertThrows(IllegalArgumentException.class, () -> {
        	appointment.setAppointmentDate(appointmentDate);
        });
	}
	
	//tests if appointmentDescription is longer than fifty
	@Test
	public void appointmentTestNotLongerThanFifty() {
        assertThrows(IllegalArgumentException.class, () -> {
    		appointment.setAppointmentDescription("I am longer than fiftyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy");
        });    
	}
	
	@Test
	//tests for when appointmentDescription is null
	public void appointmentDescriptionCheckForNull() {
        assertThrows(IllegalArgumentException.class, () -> {
    		appointment.setAppointmentDescription(null);
          });
	}
 
}






