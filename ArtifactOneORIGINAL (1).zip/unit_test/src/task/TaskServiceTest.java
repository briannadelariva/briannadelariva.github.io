package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

// Brianna De La Riva 
// Professor Norman
//CS 320 Software testing, Automation, QA
// 25 November 2023
// Module 6 Project One Submission



public class TaskServiceTest {

	
	
	TaskService taskService = new TaskService();
	static Task task1;
	static Task task2;
	
	static {
		task1 = new Task();
		task1.setTaskID("1");
		task1.setName("1-first");
		task2 = new Task();
		task2.setTaskID("2");
		task2.setName("2-first");		
	}
	//tests that a task name may be updated
		@Test
		void testNameUpdate() {
	        Task task1before = new Task();
	        task1before.setTaskID("1");
	        task1before.setName("b4Up");        

	        Task task1after = new Task();
	        task1after.setTaskID("1");
	        task1after.setName("afterUp");        
	        
			taskService.add(task1before);

	        taskService.update(task1after);
	        
	        Task updatedTask = taskService.get(task1after);
	       
	        assertEquals(updatedTask.getName(), task1after.getName(), "Didn't update the Task Name");
		}
	
		//tests that a task description may be updated
		@Test
		void testDescriptionUpdate() {
	        Task description1before = new Task();
	        description1before.setDescription("Description");
	        description1before.setTaskID("1");

	        Task description1after = new Task();
	        description1after.setDescription("Description Revised");
	        description1after.setTaskID("1");

			taskService.add(description1before);

	        taskService.update(description1after);
	        
	        Task updatedTask = taskService.get(description1after);
	       
	        assertEquals(description1before.getTaskID(), updatedTask.getTaskID(), "Id changed");
	        assertEquals(updatedTask.getDescription(), description1after.getDescription(), "Didn't update the Task Description");			
		}
		
		//tests that valid input was deleted
		@Test
		void testDeleteValid() {
			Task testDeleteValid = task1;
			taskService.add(testDeleteValid);
			Task deleted = taskService.get(testDeleteValid);
			
			// testing that addition worked. 
			assertEquals(deleted.getTaskID(), testDeleteValid.getTaskID(),"failed to get task that was added");
			
			taskService.delete(testDeleteValid);
			Task gone = taskService.get(testDeleteValid);
			assertNull(gone, "Deleted is not null");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}
