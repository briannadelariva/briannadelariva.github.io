#Brianna De La Riva
#Professor Krupa
#CS-499 Computer Science Capstone - Artifact Two, Data Structures and Algorithms
#12 September 2024

def get_season(month, day):
    # Define season boundaries and limit previous if else statements
    # Each tuple contains the season name and two tuples representing the start and end dates of the season
    # Data structure topic used - list of tuples
    seasons = [
        ("Winter", (12, 21), (3, 19)),  # Winter spans from December 21 to March 19
        ("Spring", (3, 20), (6, 20)),  # Spring spans from March 20 to June 20
        ("Summer", (6, 21), (9, 21)),  # Summer spans from June 21 to September 21
        ("Autumn", (9, 22), (12, 20)),  # Autumn spans from September 22 to December 20
    ]

    # Define days in each month for validation
    # Data structure feature used - dictionary
    days_in_month = {
        'January': 31, 'February': 28, 'March': 31, 'April': 30,
        'May': 31, 'June': 30, 'July': 31, 'August': 31,
        'September': 30, 'October': 31, 'November': 30, 'December': 31
    }

    # Convert month name to number for easier comparison
    # Data structure used - dictionary
    month_numbers = {
        'January': 1, 'February': 2, 'March': 3, 'April': 4,
        'May': 5, 'June': 6, 'July': 7, 'August': 8,
        'September': 9, 'October': 10, 'November': 11, 'December': 12
    }

    # Convert the month name to its corresponding number
    month_number = month_numbers.get(month)  # dictionary lookup

    # Validating thee  month and day
    if month_number is None or day < 1 or day > days_in_month.get(month, 0):  # Dictionary lookup
        return "Invalid"  # Return "Invalid" if the month is not found or if the day is out of the valid range

    # Checks which season the date falls into based on user input
    for season, start, end in seasons:  # List of tuples iteration
        start_month, start_day = start  # Unpack the start date
        end_month, end_day = end  # Unpack the end date

        # additional handling for year end season transition
        # If the season spans the end of the year (Winter), handle differently
        if start_month > end_month:
            # For seasons that cross the year boundary
            if (month_number > start_month or (month_number == start_month and day >= start_day)) or \
                    (month_number < end_month or (month_number == end_month and day <= end_day)):
                return season
        else:
            # For seasons that do Not cross the year boundary
            if (month_number > start_month or (month_number == start_month and day >= start_day)) and \
                    (month_number < end_month or (month_number == end_month and day <= end_day)):
                return season

    return "Invalid"  # Return "Invalid" if no season matches the date


# Obtain the user input
input_month = input("Enter month: ")  # Get the month from user input
input_day = int(input("Enter day: "))  # Get the day from user input

# Determine and print the season
print(get_season(input_month, input_day))
