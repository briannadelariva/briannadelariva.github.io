package task;


import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class TaskTest {
	Task task = new Task();
	
	
	//  tests that updates are not able to be done to initial taskID 
	@Test
	void taskTestNonUpdateableNewValue() {
		task.setTaskID("123"); 
        assertThrows(IllegalArgumentException.class, () -> {
    		task.setTaskID("456");
          });
	}

	// tests if update is the same as initial
	@Test
	void taskTestNonUpdateableSameValue() {
		task.setTaskID("123"); 
        assertThrows(IllegalArgumentException.class, () -> {
    		task.setTaskID("123");
          });
	}

	//tests if TaskID is null
	@Test
	void testNullId() {		
        assertThrows(IllegalArgumentException.class, () -> {
        	task.setTaskID(null);
        });
	}
	
	//tests if TaskName is null
	@Test
	void testNullName() {		
        assertThrows(IllegalArgumentException.class, () -> {
        	task.setName(null);
        });
	}

	//tests if TaskDescription is null
	@Test
	void testNullDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
        	task.setDescription(null);
        });

	}
	
	//tests if TaskID is too long
	@Test
	void testIdTooLong() {		
        assertThrows(IllegalArgumentException.class, () -> {
        	task.setTaskID("123456789012345678901234567890");
        });

	}
	
	//tests if TaskName is too long
	@Test
	void testNameTooLong() {		
        assertThrows(IllegalArgumentException.class, () -> {
        	task.setName("123456789012345678901234567890123456789012345678901234567890");
        });
	}
	
	//tests if TaskDescription is too long
	@Test
	void testDescriptionTooLong() {		
        assertThrows(IllegalArgumentException.class, () -> {
        	task.setDescription("123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890");
        });
	}
	
	
	
}
