package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.List;
import java.util.Calendar;

import org.junit.jupiter.api.Test;

//Brianna De La Riva
//Professor Krupa
//CS-499 Computer Science Capstone - Artifact One, Software Design and Engineering
//12 September 2024

public class AppointmentTest {

    Appointment appointment = new Appointment();
    Date futureDate = new Calendar.Builder().setDate(2024, Calendar.SEPTEMBER, 15).build().getTime(); // Example future date
    Date pastDate = new Calendar.Builder().setDate(2020, Calendar.JANUARY, 1).build().getTime(); // Example past date

    @Test
    // Tests for when appointmentID is null
    public void appointmentIDCheckForNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentID(null);
        });
    }

    // Tests that updates are not able to be done to initial appointmentID
    @Test
    public void appointmentTestNonUpdateableNewValue() {
        appointment.setAppointmentID("867");
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentID("5309");
        });
    }

    // Tests if update is the same as initial
    @Test
    public void appointmentTestNonUpdateableSameValue() {
        appointment.setAppointmentID("867");
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentID("867");
        });
    }

    // Tests if appointmentID is longer than ten charactersz
    @Test
    public void appointmentTestNotLongerThanTen() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentID("I am longer than ten");
        });
    }

    // Tests if appointmentDate is null
    @Test
    public void appointmentDateCheckForNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }

    // Tests if appointmentDate is in the past
    @Test
    public void appointmentDateIsPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(pastDate);
        });
    }

    // Tests if appointmentDescription is longer than fifty characters
    @Test
    public void appointmentTestNotLongerThanFifty() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDescription("I am longer than fiftyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy");
        });
    }

    // Tests for when appointmentDescription is null
    @Test
    public void appointmentDescriptionCheckForNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDescription(null);
        });
    }
    

    //Below are the  tests for the enhancement that were added
    
    
    // Tests generating daily recurring appointments
    @Test
    public void testRecurringAppointmentsDaily() {
        appointment.generateRecurringAppointments(futureDate, 3, "daily");
        List<Date> appointments = appointment.getRecurringAppointments();
        assertEquals(3, appointments.size(), "Should generate 3 daily appointments");

        Calendar expectedDate = Calendar.getInstance();
        expectedDate.setTime(futureDate);

        for (int i = 0; i < 3; i++) {
            expectedDate.add(Calendar.DAY_OF_YEAR, 1);
            assertEquals(expectedDate.getTime(), appointments.get(i), "Appointment date does not match");
        }
    }

    // Tests generating weekly recurring appointments
    @Test
    public void testRecurringAppointmentsWeekly() {
        appointment.generateRecurringAppointments(futureDate, 2, "weekly");
        List<Date> appointments = appointment.getRecurringAppointments();
        assertEquals(2, appointments.size(), "Should generate 2 weekly appointments");

        Calendar expectedDate = Calendar.getInstance();
        expectedDate.setTime(futureDate);

        for (int i = 0; i < 2; i++) {
            expectedDate.add(Calendar.WEEK_OF_YEAR, 1);
            assertEquals(expectedDate.getTime(), appointments.get(i), "Appointment date does not match");
        }
    }

    // Tests generating monthly recurring appointments
    @Test
    public void testRecurringAppointmentsMonthly() {
        appointment.generateRecurringAppointments(futureDate, 1, "monthly");
        List<Date> appointments = appointment.getRecurringAppointments();
        assertEquals(1, appointments.size(), "Should generate 1 monthly appointment");

        Calendar expectedDate = Calendar.getInstance();
        expectedDate.setTime(futureDate);
        expectedDate.add(Calendar.MONTH, 1);
        assertEquals(expectedDate.getTime(), appointments.get(0), "Appointment date does not match");
    }

    // Tests invalid recurrence types
    @Test
    public void testInvalidRecurrenceType() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.generateRecurringAppointments(futureDate, 1, "yearly");
        });
    }

    // Tests generating appointments with a past start date
    @Test
    public void testAppointmentInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.generateRecurringAppointments(pastDate, 1, "daily");
        });
    }
}



