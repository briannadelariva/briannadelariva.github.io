package appointment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;


public class AppointmentServiceTest {
	AppointmentService appointmentService = new AppointmentService();

	
	//tests that appointment was added
	@Test
	public void testAppointmentAdd() {
		Appointment myAppointment = new Appointment();
		myAppointment.setAppointmentID("someId");
		appointmentService.add(myAppointment);	
		Appointment afterAddAppointment = appointmentService.get(myAppointment);
		// test it worked
		assertTrue(afterAddAppointment.getAppointmentID().equals(myAppointment.getAppointmentID()), "it is not true");
		
	}
	
	@Test
	public void testAppointmentDeleted() {
		Appointment testAppointmentDeleted = new Appointment();
		testAppointmentDeleted.setAppointmentID("someId");
		appointmentService.add(testAppointmentDeleted);
		Appointment deleted = appointmentService.get(testAppointmentDeleted);
		// testing that addition worked. 
		assertEquals(deleted.getAppointmentID(), testAppointmentDeleted.getAppointmentID(),"failed to get appointment that was added");
		appointmentService.delete(testAppointmentDeleted);
		Appointment gone = appointmentService.get(testAppointmentDeleted);
		assertNull(gone, "Deleted is not null");
		
		
	}


}
