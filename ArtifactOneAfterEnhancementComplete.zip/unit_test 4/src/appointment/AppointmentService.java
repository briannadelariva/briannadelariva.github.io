package appointment;

import java.util.HashMap;
import java.util.Map;


public class AppointmentService {
	//hash map for appointment contents
	Map<String, Appointment> appointments = new HashMap<String, Appointment>();	
	//getting appts
	public Appointment get(Appointment appointment) {
		String getId = appointment.getAppointmentID();
		return appointments.get(getId);
	}
	//add appointments
	public void add(Appointment appointment) {
		appointments.put(appointment.getAppointmentID(), appointment);
	}
	//delete appointments
	public void delete(Appointment appointment) {
		appointments.remove(appointment.getAppointmentID());
	}
	

}
