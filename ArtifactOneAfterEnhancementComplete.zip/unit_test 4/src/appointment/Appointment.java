package appointment;

import java.util.Date;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.List;

//Brianna De La Riva
//Professor Krupa
//CS-499 Computer Science Capstone - Artifact One, Software Design and Engineering
//12 September 2024

public class Appointment {

    private String appointmentID;
    private String appointmentDescription;
    private Date appointmentDate;

    // added attributes for recurring appointments enhancement
    private List<Date> recurringAppointments;

    public Appointment() {
        recurringAppointments = new ArrayList<>();
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(String newAppointmentID) {
        // Appointment ID requirements 
        if (newAppointmentID == null || newAppointmentID.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must not be null and cannot be longer than 10 characters.");
        }

        if (this.appointmentID != null) {
            throw new IllegalArgumentException("Appointment ID cannot be updated.");
        }

        this.appointmentID = newAppointmentID;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    public void setAppointmentDescription(String newAppointmentDescription) {
        // Appointment description requirements
        if (newAppointmentDescription == null || newAppointmentDescription.length() > 50) {
            throw new IllegalArgumentException("Appointment description must not be null and cannot be longer than 50 characters.");
        }
        this.appointmentDescription = newAppointmentDescription;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date newAppointmentDate) {
        // Appointment date requirements
        if (newAppointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        // Appointment date must not be in the past, only in the future
        if (newAppointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be in the past.");
        }
        this.appointmentDate = newAppointmentDate;
    }

    // Method to handle recurring appointments and add it as a functionality enhancement
    public void generateRecurringAppointments(Date startDate, int recurrenceCount, String recurrenceType) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);

        for (int i = 1; i <= recurrenceCount; i++) {
            switch (recurrenceType.toLowerCase()) {
                case "daily":
                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                    break;
                case "weekly":
                    calendar.add(Calendar.WEEK_OF_YEAR, 1);
                    break;
                case "monthly":
                    calendar.add(Calendar.MONTH, 1);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid recurrence type. Use 'daily', 'weekly', or 'monthly'.");
            }

            Date nextAppointment = calendar.getTime();

            // Ensures that the next appointment is in the future too and not the past
            if (nextAppointment.before(new Date())) {
                throw new IllegalArgumentException("Next recurring appointment cannot be in the past.");
            }

            recurringAppointments.add(nextAppointment);
        }
    }

    // Getter for recurringAppointments
    public List<Date> getRecurringAppointments() {
        return recurringAppointments;
    }

    //  Method to display all recurring appointments after user has made them
    public void displayRecurringAppointments() {
        for (Date appointment : recurringAppointments) {
            System.out.println("Recurring appointment scheduled for: " + appointment);
        }
    }
}
