package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

//sets strings for variables 
class ContactTest {
	String firstName = "John";
	String firstNameLongerThan10 = "JohnJohnJohnJohnJohnJohnJohnJohn";
	String firstNameExactlyThan10 = "JohnJohnJo"; 
	String lastName = "Doe";
	String lastNameLongerThan10 = "DoeDoeDoeDoeDoeDoe";
	String lastNameExactlyThan10 = "DoeDoeDoeD"; 
	String contactID = "Jane";
	String contactIDLongerThan10 = "JaneJaneJaneJaneJaneJaneJaneJane";
	String contactIDExactlyThan10 = "JaneJaneJa"; 
	String number = "1234567890";
	String numberLongerThan10 = "12345678901";
	String numberLessThan10 = "1";
	String Address = "007 Lakeshore Drive";
	String addressLongerThan30 = "asdfghjklzxcvbnmqwertyuiopqwertyuio";
	String addressLessThan30 = "1";
	

	//tests first name requirements
	
    @Test
    void setFirstNameWithValidName() {
        Contact contact = new Contact();
        contact.setFirstName(firstName);
        String john = contact.getFirstName();
        assertEquals(firstName, john, "First name does not match");
        assertTrue(firstName.equals(john), "First name does not match");
    }
    
    @Test
    void setFirstNameWithLongName() {
        Contact contact = new Contact();
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(firstNameLongerThan10);
        });
    }
    @Test
    void setFirstNameWithNull() {
        Contact contact = new Contact();
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }
    
    // tests last name requirements
    
    @Test
    void setLastNameWithValidName() {
        Contact contact = new Contact();
        contact.setLastName(lastName);
        String doe = contact.getLastName();
        assertEquals(lastName, doe, "Last name does not match");
        assertTrue(lastName.equals(doe), "Last name does not match");
    }
    
    @Test
    void setlastNameWithLongName() {
        Contact contact = new Contact();
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(lastNameLongerThan10);
        });
    }
     @Test
     void setLastNameWithNull() {
         Contact contact = new Contact();
         assertThrows(IllegalArgumentException.class, () -> {
        	 contact.setLastName(null);
         });
        }
    	
     //tests contact requirements
     @Test
     void setcontactIDWithValidName() {
         Contact contact = new Contact();
         contact.setContactID(contactID);
         String con = contact.getContactID();
         assertEquals(contactID, con, "Contact ID does not match");
         assertTrue(contactID.equals(con), "Contact ID does not match");
     }
     
     @Test
     void setcontactIDWithLongName() {
         Contact contact = new Contact();
         assertThrows(IllegalArgumentException.class, () -> {
             contact.setContactID(contactIDLongerThan10);
         });
     }
      @Test
      void setcontactIDWithNull() {
          Contact contact = new Contact();
          assertThrows(IllegalArgumentException.class, () -> {
         	 contact.setContactID(null);
          });
         }
      
      //tests phone number requirements
      @Test
      void setcontactPhoneNumberValid() {
    	  Contact contact = new Contact();
    	  contact.setNumber(number);
          String num = contact.getNumber();
          assertEquals(number, num, "Phone Number does not match");
          assertTrue(number.equals(num), "Phone Number does not match");
      }
      @Test
      void setcontactnumberLongerThan10() {
          Contact contact = new Contact();
          assertThrows(IllegalArgumentException.class, () -> {
              contact.setNumber(numberLongerThan10);
          });
          }
      
      @Test
      void setnumberWithNull() {
          Contact contact = new Contact();
          assertThrows(IllegalArgumentException.class, () -> {
         	 contact.setNumber(null);
          });
         }
          
       @Test
       void setnumberLessThan10() {
           Contact contact = new Contact();
           assertThrows(IllegalArgumentException.class, () -> {
               contact.setNumber(numberLessThan10);
        
              });
        }
       
       //tests address requirements
       
       @Test
       void setcontactAddressValid() {
     	  Contact contact = new Contact();
     	  contact.setAddress(Address);
           String addr = contact.getAddress();
           assertEquals(Address, addr, "Address does not match");
           assertTrue(Address.equals(addr), " Address does not match");
       }
       @Test
       void setcontactaddressLongerThan30() {
           Contact contact = new Contact();
           assertThrows(IllegalArgumentException.class, () -> {
               contact.setNumber(addressLongerThan30);
           });
           }
       
       @Test
       void setaddressWithNull() {
           Contact contact = new Contact();
           assertThrows(IllegalArgumentException.class, () -> {
          	 contact.setAddress(null);
           });
          }
           
        @Test
        void setaddressLessThan30() {
            Contact contact = new Contact();
            assertThrows(IllegalArgumentException.class, () -> {
                contact.setNumber(addressLessThan30);
         
               });
         }
    }


